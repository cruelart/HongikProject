////////////////////////////////////////////////////////////////////////////////
// Filename: graphicsclass.cpp
////////////////////////////////////////////////////////////////////////////////
#include "graphicsclass.h"


GraphicsClass::GraphicsClass()
{
	m_D3D = 0;
	m_Camera = 0;
	m_Model = 0;
	m_Model1 = 0;
	m_Model2 = 0;
	m_Model3 = 0;
	m_Model4 = 0;
	m_Model5 = 0;
	m_Model6 = 0;
	m_Model7 = 0;
	m_Model8 = 0;
	m_Model9 = 0;
	m_Model10 = 0;
	m_Model11 = 0;
	m_Model12 = 0;
	m_Model13 = 0;
	m_Model14 = 0;
	m_Model15 = 0;
	m_Model16 = 0;
	m_Model17 = 0;
	m_Model18 = 0;
	m_Model19 = 0;
	m_Model20 = 0;
	m_Model21 = 0;
	m_Model22 = 0;
	m_Model23 = 0; 
	m_Model24 = 0;
	m_Model25 = 0;
	m_Model26 = 0;
	m_Model27 = 0;
	m_Model28 = 0;
	m_Model29 = 0;
	m_Model30 = 0;
	m_Model31 = 0;
	m_Model32 = 0;
	m_Model33 = 0;
	m_Model34 = 0;
	m_Model35 = 0;
	m_Model36 = 0;
	m_Model37 = 0;
	m_Model38 = 0;
	m_Model39 = 0;
	m_Model40 = 0;
	m_Model41 = 0;

	m_LightShader = 0;
	m_Light = 0;
	
}


GraphicsClass::GraphicsClass(const GraphicsClass& other)
{
}


GraphicsClass::~GraphicsClass()
{
}


bool GraphicsClass::Initialize(int screenWidth, int screenHeight, HWND hwnd)
{
	bool result;


	// Create the Direct3D object.
	m_D3D = new D3DClass;
	if(!m_D3D)
	{
		return false;
	}

	// Initialize the Direct3D object.
	result = m_D3D->Initialize(screenWidth, screenHeight, VSYNC_ENABLED, hwnd, FULL_SCREEN, SCREEN_DEPTH, SCREEN_NEAR);
	if(!result)
	{
		MessageBox(hwnd, L"Could not initialize Direct3D.", L"Error", MB_OK);
		return false;
	}

	// Create the camera object.
	m_Camera = new CameraClass;
	if(!m_Camera)
	{
		return false;
	}

	// Set the initial position of the camera.
	m_Camera->SetPosition(0.0f, -100.0f, 1000.0f);	// for cube
//	m_Camera->SetPosition(0.0f, 0.5f, -3.0f);	// for chair
		
	// Create the model object.
	m_Model = new ModelClass;
	if(!m_Model)
	{
		return false;
	}
	result = m_Model->Initialize(m_D3D->GetDevice(), L"./data/cube.obj", L"./data/seafloor.dds");

	m_Model1 = new ModelClass;
	if (!m_Model)
	{
		return false;
	}

	// Initialize the model object.
	
	result = m_Model1->Initialize(m_D3D->GetDevice(), L"./data/forest1.obj", L"./data/forest1_color.dds");
	if(!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model2 = new ModelClass;
	if (!m_Model2)
	{
		return false;
	}

	result = m_Model2->Initialize(m_D3D->GetDevice(), L"./data/floorStone1.obj", L"./data/floorStone1_color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model3 = new ModelClass;
	if (!m_Model3)
	{
		return false;
	}

	result = m_Model3->Initialize(m_D3D->GetDevice(), L"./data/mountain1.obj", L"./data/floorStone1_color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model4 = new ModelClass;
	if (!m_Model4)
	{
		return false;
	}

	result = m_Model4->Initialize(m_D3D->GetDevice(), L"./data/mountain1.obj", L"./data/floorStone1_color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model5 = new ModelClass;
	if (!m_Model5)
	{
		return false;
	}

	result = m_Model5->Initialize(m_D3D->GetDevice(), L"./data/mountain1.obj", L"./data/floorStone1_color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model6 = new ModelClass;
	if (!m_Model6)
	{
		return false;
	}

	result = m_Model6->Initialize(m_D3D->GetDevice(), L"./data/UFO.obj", L"./data/UFO_Color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model7 = new ModelClass;
	if (!m_Model7)
	{
		return false;
	}

	result = m_Model7->Initialize(m_D3D->GetDevice(), L"./data/UFO1.obj", L"./data/UFO_Color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model8 = new ModelClass;
	if (!m_Model8)
	{
		return false;
	}

	result = m_Model8->Initialize(m_D3D->GetDevice(), L"./data/bigforest.obj", L"./data/bigforest_color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model9 = new ModelClass;
	if (!m_Model9)
	{
		return false;
	}

	result = m_Model9->Initialize(m_D3D->GetDevice(), L"./data/Floor3.obj", L"./data/Floor_color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	/////////

	m_Model10 = new ModelClass;
	if (!m_Model10)
	{
		return false;
	}

	result = m_Model10->Initialize(m_D3D->GetDevice(), L"./data/Grass1.obj", L"./data/forest1_Color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model11 = new ModelClass;
	if (!m_Model11)
	{
		return false;
	}

	result = m_Model11->Initialize(m_D3D->GetDevice(), L"./data/Grass1.obj", L"./data/forest1_Color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model12 = new ModelClass;
	if (!m_Model)
	{
		return false;
	}

	// Initialize the model object.

	result = m_Model12->Initialize(m_D3D->GetDevice(), L"./data/forest1.obj", L"./data/forest1_color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model13 = new ModelClass;

	result = m_Model13->Initialize(m_D3D->GetDevice(), L"./data/home1.obj", L"./data/AnyConv.com__Texture.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model14 = new ModelClass;

	result = m_Model14->Initialize(m_D3D->GetDevice(), L"./data/Car.obj", L"./data/AnyConv.com__car_colors.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model15 = new ModelClass;

	result = m_Model15->Initialize(m_D3D->GetDevice(), L"./data/4doro.obj", L"./data/AnyConv.com__car_colors.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	///
	m_Model16 = new ModelClass;

	result = m_Model16->Initialize(m_D3D->GetDevice(), L"./data/doro.obj", L"./data/AnyConv.com__car_colors.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model17 = new ModelClass;

	result = m_Model17->Initialize(m_D3D->GetDevice(), L"./data/doro2.obj", L"./data/AnyConv.com__car_colors.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	///////////

	m_Model18 = new ModelClass;

	result = m_Model18->Initialize(m_D3D->GetDevice(), L"./data/doro2.obj", L"./data/AnyConv.com__car_colors.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}
	/// <summary>
	/// /
	/// </summary>
	/// <param name="screenWidth"></param>
	/// <param name="screenHeight"></param>
	/// <param name="hwnd"></param>
	/// <returns></returns>
	m_Model19 = new ModelClass;

	result = m_Model19->Initialize(m_D3D->GetDevice(), L"./data/doro.obj", L"./data/AnyConv.com__car_colors.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model20 = new ModelClass;

	result = m_Model20->Initialize(m_D3D->GetDevice(), L"./data/pogipan1.obj", L"./data/AnyConv.com__car_colors.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	///////////

	m_Model21 = new ModelClass;

	result = m_Model21->Initialize(m_D3D->GetDevice(), L"./data/truck.obj", L"./data/AnyConv.com__car_colors.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	// Create the light shader object.
	m_LightShader = new LightShaderClass;
	if (!m_LightShader)
	{
		return false;
	}

	/////////////////

	m_Model22 = new ModelClass;

	result = m_Model22->Initialize(m_D3D->GetDevice(), L"./data/ultari.obj", L"./data/AnyConv.com__Color Palette.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	///////////
	m_Model23 = new ModelClass;

	result = m_Model23->Initialize(m_D3D->GetDevice(), L"./data/ultari1.obj", L"./data/AnyConv.com__Color Palette.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	///////////

	m_Model24 = new ModelClass;

	result = m_Model24->Initialize(m_D3D->GetDevice(), L"./data/house2.obj", L"./data/AnyConv.com__house_BaseColor.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	///////////

	m_Model25 = new ModelClass;

	result = m_Model25->Initialize(m_D3D->GetDevice(), L"./data/ultari2.obj", L"./data/AnyConv.com__Color Palette.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	//////////

	m_Model26 = new ModelClass;

	result = m_Model26->Initialize(m_D3D->GetDevice(), L"./data/pungcha.obj", L"./data/AnyConv.com__Color Palette.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	////////////////

	m_Model27 = new ModelClass;

	result = m_Model27->Initialize(m_D3D->GetDevice(), L"./data/tree.obj", L"./data/AnyConv.com__Color Palette.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	///////////

	m_Model28 = new ModelClass;

	result = m_Model28->Initialize(m_D3D->GetDevice(), L"./data/bigUFO.obj", L"./data/UFO_Color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	///////

	m_Model29 = new ModelClass;

	result = m_Model29->Initialize(m_D3D->GetDevice(), L"./data/UFOcol.obj", L"./data/bigforest_color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	///////////////////

	m_Model30 = new ModelClass;

	result = m_Model30->Initialize(m_D3D->GetDevice(), L"./data/police1.obj", L"./data/AnyConv.com__police_car.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model31 = new ModelClass;

	result = m_Model31->Initialize(m_D3D->GetDevice(), L"./data/police2.obj", L"./data/AnyConv.com__police_car.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model32 = new ModelClass;

	result = m_Model32->Initialize(m_D3D->GetDevice(), L"./data/police3.obj", L"./data/AnyConv.com__tex.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model33 = new ModelClass;

	result = m_Model33->Initialize(m_D3D->GetDevice(), L"./data/police4.obj", L"./data/AnyConv.com__tex.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model34 = new ModelClass;

	result = m_Model34->Initialize(m_D3D->GetDevice(), L"./data/police4.obj", L"./data/AnyConv.com__tex.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model35 = new ModelClass;

	result = m_Model35->Initialize(m_D3D->GetDevice(), L"./data/pungchadolligy.obj", L"./data/AnyConv.com__Color Palette.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model36 = new ModelClass;

	result = m_Model36->Initialize(m_D3D->GetDevice(), L"./data/copter.obj", L"./data/AnyConv.com__HueyTXTR3.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	/////////////////////////

	m_Model37 = new ModelClass;

	result = m_Model37->Initialize(m_D3D->GetDevice(), L"./data/copter2.obj", L"./data/AnyConv.com__HueyTXTR3.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model38 = new ModelClass;

	result = m_Model38->Initialize(m_D3D->GetDevice(), L"./data/bari1.obj", L"./data/AnyConv.com__Barricade_distressed_T.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model39 = new ModelClass;

	result = m_Model39->Initialize(m_D3D->GetDevice(), L"./data/bari1.obj", L"./data/AnyConv.com__Barricade_distressed_T.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model40 = new ModelClass;

	result = m_Model40->Initialize(m_D3D->GetDevice(), L"./data/police4.obj", L"./data/AnyConv.com__tex.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_Model41 = new ModelClass;

	result = m_Model41->Initialize(m_D3D->GetDevice(), L"./data/bigforest.obj", L"./data/bigforest_color.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	// Create the light shader object.
	m_LightShader = new LightShaderClass;
	if (!m_LightShader)
	{
		return false;
	}

	// Initialize the light shader object.
	result = m_LightShader->Initialize(m_D3D->GetDevice(), hwnd);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the light shader object.", L"Error", MB_OK);
		return false;
	}

	// Create the light object.
	m_Light = new LightClass;
	if (!m_Light)
	{
		return false;
	}

	// Initialize the light object.
	m_Light->SetAmbientColor(0.15f, 0.15f, 0.15f, 1.0f);
//	m_Light->SetAmbientColor(0.0f, 0.0f, 0.0f, 1.0f);
	m_Light->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
//	m_Light->SetDiffuseColor(0.0f, 0.0f, 0.0f, 1.0f);
//	m_Light->SetDirection(0.0f, 0.0f, 1.0f);
	m_Light->SetDirection(1.0f, -1.0f, 0.0f);
	m_Light->SetSpecularColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_Light->SetSpecularPower(32.0f);

	return true;
}


void GraphicsClass::Shutdown()
{
	// Release the model object.
	if(m_Model)
	{
		m_Model->Shutdown();
		delete m_Model;
		m_Model = 0;
	}

	if (m_Model1)
	{
		m_Model1->Shutdown();
		delete m_Model1;
		m_Model1 = 0;
	}

	if (m_Model2)
	{
		m_Model2->Shutdown();
		delete m_Model2;
		m_Model2 = 0;
	}

	if (m_Model3)
	{
		m_Model3->Shutdown();
		delete m_Model3;
		m_Model3 = 0;
	}

	if (m_Model4)
	{
		m_Model4->Shutdown();
		delete m_Model4;
		m_Model4 = 0;
	}

	if (m_Model5)
	{
		m_Model5->Shutdown();
		delete m_Model5;
		m_Model5 = 0;
	}

	if (m_Model6)
	{
		m_Model6->Shutdown();
		delete m_Model6;
		m_Model6 = 0;
	}

	if (m_Model7)
	{
		m_Model7->Shutdown();
		delete m_Model7;
		m_Model7 = 0;
	}

	if (m_Model8)
	{
		m_Model8->Shutdown();
		delete m_Model8;
		m_Model8 = 0;
	}

	if (m_Model9)
	{
		m_Model9->Shutdown();
		delete m_Model9;
		m_Model9 = 0;
	}

	if (m_Model10)
	{
		m_Model10->Shutdown();
		delete m_Model10;
		m_Model10 = 0;
	}

	if (m_Model11)
	{
		m_Model11->Shutdown();
		delete m_Model11;
		m_Model11 = 0;
	}

	if (m_Model12)
	{
		m_Model12->Shutdown();
		delete m_Model12;
		m_Model12 = 0;
	}

	if (m_Model13)
	{
		m_Model13->Shutdown();
		delete m_Model13;
		m_Model13 = 0;
	}

	if (m_Model14)
	{
		m_Model14->Shutdown();
		delete m_Model14;
		m_Model14 = 0;
	}

	if (m_Model15)
	{
		m_Model15->Shutdown();
		delete m_Model15;
		m_Model15 = 0;
	}

	if (m_Model16)
	{
		m_Model16->Shutdown();
		delete m_Model16;
		m_Model16 = 0;
	}

	if (m_Model17)
	{
		m_Model17->Shutdown();
		delete m_Model17;
		m_Model17 = 0;
	}

	if (m_Model18)
	{
		m_Model18->Shutdown();
		delete m_Model18;
		m_Model18 = 0;
	}

	if (m_Model19)
	{
		m_Model19->Shutdown();
		delete m_Model19;
		m_Model19 = 0;
	}

	if (m_Model20)
	{
		m_Model20->Shutdown();
		delete m_Model20;
		m_Model20 = 0;
	}

	if (m_Model21)
	{
		m_Model21->Shutdown();
		delete m_Model21;
		m_Model21 = 0;
	}

	if (m_Model22)
	{
		m_Model22->Shutdown();
		delete m_Model22;
		m_Model22 = 0;
	}
	/// <summary>
	/// ////////
	/// </summary>
	if (m_Model23)
	{
		m_Model23->Shutdown();
		delete m_Model23;
		m_Model23 = 0;

	}

	if (m_Model24)
	{
		m_Model24->Shutdown();
		delete m_Model24;
		m_Model24 = 0;
	}

	if (m_Model25)
	{
		m_Model25->Shutdown();
		delete m_Model25;
		m_Model25 = 0;
	}

	if (m_Model26)
	{
		m_Model26->Shutdown();
		delete m_Model26;
		m_Model26 = 0;
	}

	if (m_Model27)
	{
		m_Model27->Shutdown();
		delete m_Model27;
		m_Model27 = 0;
	}

	if (m_Model28)
	{
		m_Model28->Shutdown();
		delete m_Model28;
		m_Model28 = 0;
	}

	if (m_Model29)
	{
		m_Model29->Shutdown();
		delete m_Model29;
		m_Model29 = 0;
	}

	if (m_Model30)
	{
		m_Model30->Shutdown();
		delete m_Model30;
		m_Model30 = 0;
	}

	if (m_Model31)
	{
		m_Model31->Shutdown();
		delete m_Model31;
		m_Model31 = 0;
	}

	if (m_Model32)
	{
		m_Model32->Shutdown();
		delete m_Model32;
		m_Model32 = 0;
	}

	if (m_Model33)
	{
		m_Model33->Shutdown();
		delete m_Model33;
		m_Model33 = 0;
	}

	if (m_Model34)
	{
		m_Model34->Shutdown();
		delete m_Model34;
		m_Model34 = 0;
	}

	if (m_Model35)
	{
		m_Model35->Shutdown();
		delete m_Model35;
		m_Model35 = 0;
	}

	if (m_Model36)
	{
		m_Model36->Shutdown();
		delete m_Model36;
		m_Model36 = 0;
	}

	if (m_Model37)
	{
		m_Model37->Shutdown();
		delete m_Model37;
		m_Model37 = 0;
	}

	if (m_Model38)
	{
		m_Model38->Shutdown();
		delete m_Model38;
		m_Model38 = 0;
	}

	if (m_Model39)
	{
		m_Model39->Shutdown();
		delete m_Model39;
		m_Model39 = 0;
	}

	if (m_Model40)
	{
		m_Model40->Shutdown();
		delete m_Model40;
		m_Model40 = 0;
	}

	if (m_Model41)
	{
		m_Model41->Shutdown();
		delete m_Model41;
		m_Model41 = 0;
	}

	// Release the camera object.
	if(m_Camera)
	{
		delete m_Camera;
		m_Camera = 0;
	}

	// Release the D3D object.
	if(m_D3D)
	{
		m_D3D->Shutdown();
		delete m_D3D;
		m_D3D = 0;
	}

	// Release the light object.
	if (m_Light)
	{
		delete m_Light;
		m_Light = 0;
	}

	// Release the light shader object.
	if (m_LightShader)
	{
		m_LightShader->Shutdown();
		delete m_LightShader;
		m_LightShader = 0;
	}
	
	return;
}

bool GraphicsClass::Frame()
{
	bool result;

	static float rotation = 0.0f;


	// Update the rotation variable each frame.
	rotation += XM_PI * 0.0015f;
	if (rotation > 360.0f)
	{
		rotation -= 360.0f;
	}

	// Render the graphics scene.
	result = Render(rotation);
	if(!result)
	{
		return false;
	}


	return true;
}

bool GraphicsClass::Render(float rotation)
{
	XMMATRIX worldMatrix, viewMatrix, projectionMatrix;
	bool result;
	
	// Clear the buffers to begin the scene.
	m_D3D->BeginScene(0.0f, 0.0f, 0.0f, 1.0f);

	// Generate the view matrix based on the camera's position.
	m_Camera->Render();

	// Get the world, view, and projection matrices from the camera and d3d objects.
	m_Camera->GetViewMatrix(viewMatrix);
	m_D3D->GetWorldMatrix(worldMatrix);
	m_D3D->GetProjectionMatrix(projectionMatrix);

	// Rotate the world matrix by the rotation value so that the triangle will spin.
	worldMatrix *= XMMatrixRotationY(rotation);

	// Put the model vertex and index buffers on the graphics pipeline to prepare them for drawing.
	m_Model->Render(m_D3D->GetDeviceContext());

	worldMatrix *= XMMatrixTranslation(50.0f, -50.0f, -6.0f);

	// Render the model using the light shader.
	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());
	
	if(!result)
	{
		return false;
	}
	/// <summary>
	/// //////////
	/// </summary>
	/// <param name="rotation"></param>
	/// <returns></returns>
	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(140.0f, -41.0f, -6.0f);

	m_Model1->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model1->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model1->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}
	/// <summary>
	/// //////////////////
	/// </summary>
	/// <param name="rotation"></param>
	/// <returns></returns>
	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(100.0f, -60.0f, -6.0f);

	m_Model2->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model2->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model2->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	/////////////////////////////
	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(200.0f, -40.0f, -30.0f);

	m_Model3->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model3->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model3->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}
	////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(200.0f, -40.0f, 0.0f);

	m_Model4->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model4->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model4->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}


	///////////////
	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(200.0f, -40.0f, 40.0f);

	m_Model5->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model5->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model5->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}
	/////////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������
	worldMatrix *= XMMatrixRotationY(rotation);

	worldMatrix *= XMMatrixTranslation(40.0f, 5.0f, -6.0f);

	worldMatrix *= XMMatrixRotationY(rotation);

	m_Model6->Render(m_D3D->GetDeviceContext()); // ������

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model6->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model6->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	/////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������
	worldMatrix *= XMMatrixRotationY(rotation);

	worldMatrix *= XMMatrixTranslation(20.0f, 0.0f, 20.0f);

	m_Model7->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model7->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model7->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(20.0f, -18.0f, 60.0f);

	m_Model8->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model8->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model8->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	///////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(110.0f, -40.0f, -18.0f);

	m_Model9->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model9->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model9->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	///////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(-30.0f, -50.0f, 10.0f);

	m_Model10->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model10->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model10->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(-30.0f, -50.0f, 90.0f);

	m_Model11->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model11->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model11->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	///////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(140.0f, -41.0f, 20.0f);

	m_Model12->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model12->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model12->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	/////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(60.0f, -41.0f, 10.0f);

	m_Model13->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model13->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model13->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	/////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(150.0f, -40.0f, -123.0f);

	m_Model14->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model14->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model14->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	//////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(100.0f, -40.0f, -70.0f);

	m_Model15->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model15->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model15->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	/////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(100.0f, -40.0f, -118.0f);

	m_Model16->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model16->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model16->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(148.0f, -40.0f, -70.0f);

	m_Model17->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model17->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model17->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	///////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(-38.0f, -40.0f, -70.0f);

	m_Model18->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model18->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model18->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	//////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(100.0f, -40.0f, 58.0f);

	m_Model19->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model19->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model19->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	//////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(80.0f, -40.0f, -60.0f);

	m_Model20->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model20->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model20->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}
	/// <summary>
	/// /////////
	/// </summary>
	/// <param name="rotation"></param>
	/// <returns></returns>
	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(50.0f, -41.0f, 10.0f);

	m_Model21->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model21->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model21->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(60.0f, -41.0f, 8.0f);

	m_Model22->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model22->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model22->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	/////////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(180.0f, -41.0f, -200.0f);

	m_Model23->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model23->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model23->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	///////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(180.0f, -41.0f, -220.0f);

	m_Model24->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model24->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model23->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(230.0f, -41.0f, -180.0f);

	m_Model25->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model25->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model25->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	//////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(170.0f, -41.0f, -150.0f);

	m_Model26->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model26->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model26->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	///////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(130.0f, -31.0f, -150.0f);

	m_Model27->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model27->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model27->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	///////////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(0.0f, -31.0f, -150.0f);

	m_Model28->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model28->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model28->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	/////////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(0.0f, -42.0f, -150.0f);

	m_Model29->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model29->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model29->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	////////////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(70.0f, -39.0f, -73.0f);

	m_Model30->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model30->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model30->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	//////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(80.0f, -39.0f, -53.0f);

	m_Model31->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model31->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model31->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	/////////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(70.0f, -39.0f, -103.0f);

	m_Model32->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model32->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model32->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	//////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(60.0f, -39.0f, -103.0f);

	m_Model33->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model33->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model33->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	//////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(55.0f, -39.0f, -93.0f);

	m_Model34->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model34->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model34->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixRotationX(rotation);

	worldMatrix *= XMMatrixTranslation(167.0f, -22.0f, -151.0f);


	m_Model35->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model35->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model35->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	//////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(55.0f, -0.0f, -103.0f);

	m_Model36->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model36->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model36->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	//////////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(-30.0f, 20.0f, -30.0f);

	m_Model37->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model37->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model37->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	/////////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(55.0f, -40.0f, -93.0f);

	m_Model38->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model38->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model38->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	//////////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(15.0f, -40.0f, -93.0f);

	m_Model39->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model39->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model39->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}
	/////////////
	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(5.0f, -40.0f, -93.0f);

	m_Model40->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model40->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model40->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	//////////////////

	m_D3D->GetWorldMatrix(worldMatrix); // ȸ�����ϰ� �ʱ�ȭ ������

	worldMatrix *= XMMatrixTranslation(100.0f, -18.0f, 90.0f);

	m_Model41->Render(m_D3D->GetDeviceContext());

	result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model41->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
		m_Model41->GetTexture(), m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());

	if (!result)
	{
		return false;
	}

	// Present the rendered scene to the screen.
	m_D3D->EndScene();

	return true;
}